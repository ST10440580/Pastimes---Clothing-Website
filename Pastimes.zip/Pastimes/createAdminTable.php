<?php
include("config/DBConn.php");

$sql = "DROP TABLE IF EXISTS tbladmin";
$conn->query($sql);

$sql = "CREATE TABLE tbladmin (
    adminID INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL
)";
$conn->query($sql);

$file = fopen("adminData.txt", "r");
if ($file) {
    while (($line = fgets($file)) !== false) {
        $data = explode(",", trim($line));
        if (count($data) == 4) {
            $username = $conn->real_escape_string($data[0]);
            $email    = $conn->real_escape_string($data[1]);
            $password = md5($conn->real_escape_string($data[2]));
            $role     = $conn->real_escape_string($data[3]);

            $sql = "INSERT INTO tbladmin (username, email, password, role)
                    VALUES ('$username', '$email', '$password', '$role')";
            $conn->query($sql);
        }
    }
    fclose($file);
}

echo "tbladmin recreated and data loaded successfully!";
?>
