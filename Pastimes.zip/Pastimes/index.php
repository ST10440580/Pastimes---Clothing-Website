<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&family=Rock+Salt&display=swap" rel="stylesheet">

</head>



<body>

<nav class="nav-home">
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes</span>
  </div>
  <div class="nav-links">
    <a href="index.php"><i class="fas fa-home"></i><span>Home</span></a> 
    <a href="register.php"><i class="fas fa-user-plus"></i><span>Register</span></a>
    <a href="login.php"><i class="fas fa-sign-in-alt"></i><span>Login</span></a>
    <a href="adminLogin.php"><i class="fas fa-user-shield"></i><span>Admin</span></a>
    <a href="sellerLogin.php"><i class="fas fa-store"></i><span>Seller</span></a>
  </div>
</nav>





<header class="logo-section">
  <!-- Background video -->
  <video autoplay muted loop class="bg-video">
    <source src="header_video.mp4" type="video/mp4">
    Your browser does not support the video tag.
  </video>



  <!-- Overlay content -->
  <div class="logo-content">
    <h1>Pastimes</h1>
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
  </div>
</header>



  <section class="slideshow-about">
  <div class="slideshow">
    <img src="images/look.jpg" class="active" alt="Fashion 1">
    <img src="images/indexpic.jpg" alt="Fashion 2">
    <img src="images/look2.jpg" alt="Fashion 3">
    <img src="images/look1.jpg" alt="Fashion 4">
    <img src="images/look3.jpg" alt="Fashion 5">
  </div>



  <div class="about-text">
    <h2>Discover Your Style</h2>
    <p>Browse our curated collection of second-hand fashion.</p>
    <p>Affordable, sustainable, and always stylish.</p>
    <p>Join thousands of shoppers embracing eco-friendly fashion choices.</p>
    <a href="products.php" class="btn-cart">Shop Now</a>



    <h2>Why Choose Pastimes?</h2>
    <p>We believe fashion should be sustainable, affordable, and expressive. Every item in our store is carefully selected to give you quality and style without breaking the bank.</p>
  </div>
</section>


<section class="featured">
  <h2>Featured Collections</h2>
  <div class="slider">
    <div class="slide active">
      <div class="card">
        <img src="images/drip_ad.jpg" alt="Stylish Jackets">
        <div class="card-info">
          <h3>Current Trends</h3>
        </div>
      </div>
    </div>
    <div class="slide">
      <div class="card">
        <img src="images/cozy_fits.jpg" alt="Elegant Dresses">
        <div class="card-info">
          <h3>Cozy Trends</h3>
        </div>
      </div>
    </div>
    <div class="slide">
      <div class="card">
        <img src="images/drippy.jpg" alt="Trendy Shoes">
        <div class="card-info">
          <h3>"Drippy" Trends</h3>
        </div>
      </div>
    </div>
    <div class="slide">
      <div class="card">
        <img src="images/designeritems.jpg" alt="Designer Items">
        <div class="card-info">
          <h3>Designer Trends</h3>
        </div>
      </div>
    </div>
    <div class="slide">
      <div class="card">
        <img src="images/highfashion.jpg" alt="Accessories">
        <div class="card-info">
          <h3>High Fashion Trends</h3>
        </div>
      </div>
    </div>
    <div class="slide">
      <div class="card">
        <img src="images/coolaccessories.jpg" alt="Headwear">
        <div class="card-info">
          <h3>Cool Accessories</h3>
        </div>
      </div>
    </div>
    <div class="slide">
      <div class="card">
        <img src="images/gymtrends.jpg" alt="Gym Wear">
        <div class="card-info">
          <h3>Gym Trends</h3>
        </div>
      </div>
    </div>
    <div class="slide">
      <div class="card">
        <img src="images/collectorsitems.jpg" alt="Collectors Items">
        <div class="card-info">
          <h3>Collectors Items</h3>
        </div>
      </div>
    </div>

    <!-- Navigation arrows -->
    <button class="prev">&#10094;</button>
    <button class="next">&#10095;</button>
  </div>

  <!-- Dots navigation -->
  <div class="dots"></div>
</section>

  





    <!-- About Section -->
   <section class="seller-info">
  <div class="seller-content">
    <div class="seller-text">
      <h2>Become a Seller on Pastimes</h2>
      <p>Do you have quality second-hand fashion items to share? Join our community of sellers and reach thousands of eco-conscious shoppers.</p>
      <ul>
        <li>Easy registration and seller dashboard</li>
        <li>Direct communication with buyers and admins</li>
        <li>Secure approval process for listed items</li>
        <li>Promote sustainable fashion and earn income</li>
      </ul>
      <section class="about">
        <h2>Note:</h2>
        <p>Please ensure that you create an account in order to shop with us or to become a seller.</p>
    </section>
      <a href="sellerRegister.php" class="btn-cart">Register as a Seller</a>
    </div>
    <div class="seller-image">
      <img src="images/seller.jpg" alt="Seller Fashion Showcase">
    </div>
  </div>
</section>


<footer>
  <div class="footer-links">
    <h4>Quick Links</h4>
    <p>
      <a href="contact.php">Contact Us</a> | 
      <a href="about.php">About</a> | 
      <a href="privacy.php">Privacy Policy</a> | 
      <a href="faq.php">FAQ</a> | 
      <a href="returns.php">Returns & Exchanges</a>
    </p>
  </div>

  <div class="footer-info">
    <h4>Store Info</h4>
    <p>📍 Johannesburg, South Africa</p>
    <p>📧 support@pastimes.com</p>
    <p>☎ +27 11 123 4567</p>
    <p>🕒 Mon–Fri: 9am – 6pm | Sat: 10am – 4pm</p>
  </div>

  <div class="footer-social">
    <h4>Follow Us</h4>
    <a href="https://www.facebook.com">Facebook</a>
    <a href="https://www.instagram.com">Instagram</a>
    <a href="https://www.twitter.com">Twitter</a>
  </div>

  <div class="footer-bottom">
    <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
  </div>
</footer>



<!-- Slideshow + Featured Collections Script -->
<script>
  /* ---------------- Slideshow (auto-play) ---------------- */
  const slides = document.querySelectorAll(".slideshow img");
  let slideIndex = 0;
  const intervalTime = 4000; // 4 seconds

  function showSlide(newIndex) {
    slides[slideIndex].classList.remove("active");
    slideIndex = newIndex;
    slides[slideIndex].classList.add("active");
  }

  function showNextSlide() {
    let nextIndex = (slideIndex + 1) % slides.length;
    showSlide(nextIndex);
  }

  setInterval(showNextSlide, intervalTime);

  /* ---------------- Featured Collections Slider ---------------- */
  const collectionSlides = document.querySelectorAll(".slider .slide");
  let collectionIndex = 0;

  function showCollectionSlide(newIndex) {
    collectionSlides[collectionIndex].classList.remove("active");
    collectionIndex = newIndex;
    collectionSlides[collectionIndex].classList.add("active");
  }



  document.querySelector(".prev").addEventListener("click", () => {
    let prevIndex = (collectionIndex - 1 + collectionSlides.length) % collectionSlides.length;
    showCollectionSlide(prevIndex);
  });

  document.querySelector(".next").addEventListener("click", () => {
    let nextIndex = (collectionIndex + 1) % collectionSlides.length;
    showCollectionSlide(nextIndex);
  });


</script>












    
</body>
</html>
