<?php
session_start();
include("config/DBConn.php");

// Assume logged-in userID is stored in session
$userID = $_SESSION['userID'];
$total = 0;
$message = "";

if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
    $ids = implode(",", $_SESSION['cart']);
    $result = $conn->query("SELECT * FROM tblclothes WHERE clothesID IN ($ids)");
    while ($row = $result->fetch_assoc()) {
        $total += $row['price'];
    }

    $orderDate = date("Y-m-d H:i:s");
    $status = "Pending";

    $sql = "INSERT INTO tblorder (userID, orderDate, status, totalAmount)
            VALUES ('$userID', '$orderDate', '$status', '$total')";
    if ($conn->query($sql) === TRUE) {
        $message = "<div class='order-success'>Order placed successfully!</div>";
        $_SESSION['cart'] = []; // clear cart
    } else {
        $message = "<div class='order-error'>Error: " . $conn->error . "</div>";
    }
} else {
    $message = "<div class='order-empty'>Cart is empty.</div>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Place Order</title>
    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
    <header>Pastimes</header>
    <nav>
        <a href="index.php">Home</a>
        <a href="products.php">Products</a>
        <a href="viewCart.php">Cart</a>
        <a href="register.php">Register</a>
    </nav>

    <h2>Order Status</h2>
    <?php echo $message; ?>
</body>
</html>
