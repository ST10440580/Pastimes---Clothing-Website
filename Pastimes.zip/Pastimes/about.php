<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
    <header>Pastimes</header>
   

    <section class="about">
        <h2>About Us</h2>
        <p>Pastimes Clothing Store is dedicated to bringing you stylish, affordable, and high‑quality fashion. 
        Our mission is to combine modern trends with timeless designs, giving our customers confidence in every outfit.</p>
        <a href="products.php" class="btn-view">Browse Products</a>
    </section>



   <!-- Footer -->
    <footer>
        <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
        <p>
             <a href="index.php">Home</a> | 
            <a href="contact.php">Contact Us</a> | 
            <a href="about.php">About</a> | 
            <a href="privacy.php">Privacy Policy</a>
        </p>
    </footer>
</body>
</html>
