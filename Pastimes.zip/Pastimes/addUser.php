<?php
include("config/DBConn.php");

$fullName = $_POST['fullName'];
$email    = $_POST['email'];
$username = $_POST['username'];
$password = md5($_POST['password']);

$sql = "INSERT INTO tblUser (fullName, email, username, password, verified)
        VALUES ('$fullName', '$email', '$username', '$password', 0)";
$conn->query($sql);

echo "New customer added successfully (pending verification). <a href='adminDashboard.php'>Back</a>";
?>
