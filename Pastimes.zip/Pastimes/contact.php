
<!DOCTYPE html>
<html>
<head>
    <title>Contact Us</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>Pastimes</header>
 

    <section class="about">
        <h2>Contact Us</h2>
        <p>If you have any questions, feedback, or need assistance, we’d love to hear from you.</p>
        <p>Email: <a href="mailto:ST10440580@rcconnect.edu.za">ST10440580@rcconnect.edu.za</a></p>
        <p>Email: <a href="mailto:ST10440580@rcconnect.edu.za">ST10440580@rcconnect.edu.za</a></p>
        <p>Phone: +27 84 370 0565</p>
        <p>Address: Johannesburg, South Africa</p>
    </section>

   <!-- Footer -->
    <footer>
        <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
        <p>
             <a href="index.php">Home</a> | 
            <a href="contact.php">Contact Us</a> | 
            <a href="about.php">About</a> | 
            <a href="privacy.php">Privacy Policy</a>
        </p>
    </footer>

</body>
</html>
