
 <!-- Navigation -->
  <nav>
    <div class="nav-logo">
      <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
      <span class="brand-name">Pastimes</span>
    </div>
    <div class="nav-links">
      <a href="index.php"><i class="fas fa-home"></i><span>Home</span></a>
      <a href="products.php"><i class="fas fa-tshirt"></i><span>Products</span></a>
      <a href="viewCart.php"><i class="fas fa-shopping-cart"></i><span>My Cart</span></a>
      
    </div>
  </nav>
<?php
session_start();
include("config/DBConn.php");

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['userID'])) {
        echo "You must be logged in to place an order.";
    } else {
        $stmt = $conn->prepare("INSERT INTO tbldelivery (userID, name, address, city, postal, phone) 
                                VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssss", $_SESSION['userID'], $_POST['name'], $_POST['address'], $_POST['city'], $_POST['postal'], $_POST['phone']);
        if ($stmt->execute()) {
            header("Location: orderConfirmation.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Delivery Details</title>
  <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>


<body>
  <h2>Enter Your Delivery Details</h2>
  <form method="POST" action="">
    <label>Full Name:</label>
    <input type="text" name="name" required>

    <label>Address:</label>
    <input type="text" name="address" required>

    <label>City:</label>
    <input type="text" name="city" required>

    <label>Postal Code:</label>
    <input type="text" name="postal" required>

    <label>Phone Number:</label>
    <input type="text" name="phone" required>

    <input type="submit" value="Confirm Order">
  </form>
</body>


 <footer>
  <div class="footer-links">
    <h4>Quick Links</h4>
    <p>
      <a href="contact.php">Contact Us</a> | 
      <a href="about.php">About</a> | 
      <a href="privacy.php">Privacy Policy</a> | 
      <a href="faq.php">FAQ</a> | 
      <a href="returns.php">Returns & Exchanges</a>
    </p>
  </div>

  <div class="footer-info">
    <h4>Store Info</h4>
    <p>📍 Johannesburg, South Africa</p>
    <p>📧 support@pastimes.com</p>
    <p>☎ +27 11 123 4567</p>
    <p>🕒 Mon–Fri: 9am – 6pm | Sat: 10am – 4pm</p>
  </div>

  <div class="footer-social">
    <h4>Follow Us</h4>
    <a href="https://www.facebook.com">Facebook</a>
    <a href="https://www.instagram.com">Instagram</a>
    <a href="https://www.twitter.com">Twitter</a>
  </div>

  <div class="footer-bottom">
    <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
  </div>
</footer>
</html>
