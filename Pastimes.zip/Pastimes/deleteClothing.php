<?php
include("config/DBConn.php"); // adjust path if needed

// Get clothing item ID safely
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    // First fetch the image filename so we can delete the file too
    $result = $conn->query("SELECT image FROM tblclothes WHERE clothesID=$id");
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $imageFile = "images/" . $row['image'];

        // Delete record from database
        $sql = "DELETE FROM tblclothes WHERE clothesID=$id";
        if ($conn->query($sql) === TRUE) {
            // Optionally delete the image file if it exists
            if (file_exists($imageFile)) {
                unlink($imageFile);
            }
            echo "<script>alert('Clothing item deleted successfully!'); window.location.href='manageClothing.php';</script>";
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    } else {
        echo "<h2 style='color:red; text-align:center;'>Clothing item not found.</h2>";
    }
} else {
    echo "<h2 style='color:red; text-align:center;'>Invalid clothing ID.</h2>";
}
?>
