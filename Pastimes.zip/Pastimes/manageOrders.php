<?php
include("config/DBConn.php");

$result = $conn->query("SELECT o.orderID, u.fullName, o.orderDate, o.status, o.totalAmount
                        FROM tblorder o
                        JOIN tbluser u ON o.userID = u.userID");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Orders</title>
    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
   
    <nav class="admin-nav">
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes Admin</span>
  </div>
  <div class="nav-links">
    <a href="index.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    <a href="adminDashboard.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
  </div>
</nav>


    <section class="about">
        <h2>Manage Orders</h2>
        <table class="cart-table">
            <tr>
                <th>OrderID</th>
                <th>Customer</th>
                <th>Date</th>
                <th>Status</th>
                <th>Total</th>
                <th>Action</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['orderID']; ?></td>
                    <td><?php echo $row['fullName']; ?></td>
                    <td><?php echo $row['orderDate']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td>R<?php echo $row['totalAmount']; ?></td>
                    <td>
                        <a href="updateOrder.php?id=<?php echo $row['orderID']; ?>&status=Shipped" class="btn-cart">Mark Shipped</a>
                        <a href="updateOrder.php?id=<?php echo $row['orderID']; ?>&status=Delivered" class="btn-view">Mark Delivered</a>
                        <a href="updateOrder.php?id=<?php echo $row['orderID']; ?>&status=Cancelled" class="btn-remove">Cancel</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </section>

    <footer>
        <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
    </footer>
</body>
</html>
