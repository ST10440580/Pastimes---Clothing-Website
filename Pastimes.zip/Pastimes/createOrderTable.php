<?php
include("config/DBConn.php");

$sql = "DROP TABLE IF EXISTS tblorder";
$conn->query($sql);

$sql = "CREATE TABLE tblorder (
    orderID INT AUTO_INCREMENT PRIMARY KEY,
    userID INT NOT NULL,
    orderDate DATETIME NOT NULL,
    status VARCHAR(20) NOT NULL,
    totalAmount DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (userID) REFERENCES tbluser(userID)
)";
$conn->query($sql);

$file = fopen("orderData.txt", "r");
if ($file) {
    while (($line = fgets($file)) !== false) {
        $data = explode(",", trim($line));
        if (count($data) == 4) {
            $userID      = $conn->real_escape_string($data[0]);
            $orderDate   = $conn->real_escape_string($data[1]);
            $status      = $conn->real_escape_string($data[2]);
            $totalAmount = $conn->real_escape_string($data[3]);

            $sql = "INSERT INTO tblorder (userID, orderDate, status, totalAmount)
                    VALUES ('$userID', '$orderDate', '$status', '$totalAmount')";
            $conn->query($sql);
        }
    }
    fclose($file);
}

echo "tblorder recreated and data loaded successfully!";
?>
