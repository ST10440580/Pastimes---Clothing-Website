<?php
include("config/DBConn.php");
session_start();

// ✅ Only Admins can access
if (!isset($_SESSION['adminID']) || !in_array(strtolower($_SESSION['role']), ['admin','superadmin','moderator','manager','staff','editor'])) {
    die("<h2 style='color:red; text-align:center;'>Access denied. Only Admins can communicate.</h2>");
}

// ✅ Define $users before HTML output
$users = $conn->query("SELECT userID, username, role FROM tbluser WHERE role IN ('Seller','Customer')");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $receiverID = intval($_POST['receiverID']);
    $roleTo = $_POST['roleTo'];
    $subject = $_POST['subject'];
    $body = $_POST['body'];

    $sql = "INSERT INTO tblmessages (senderID, receiverID, roleFrom, roleTo, subject, body)
            VALUES (?, ?, 'Admin', ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iisss", $_SESSION['adminID'], $receiverID, $roleTo, $subject, $body);

    if ($stmt->execute()) {
        echo "<script>alert('Message sent successfully!');</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Communication</title>
    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<nav class="admin-nav">
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes Admin</span>
  </div>
  <div class="nav-links">
    <a href="index.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    <a href="manageOrders.php"><i class="fas fa-box"></i><span>Manage Orders</span></a>
    <a href="manageClothing.php"><i class="fas fa-tshirt"></i><span>Manage Clothing</span></a>
    <a href="manageRequests.php"><i class="fas fa-tasks"></i><span>Clothing Requests</span></a>
    <a href="adminCommunicate.php"><i class="fas fa-envelope"></i><span>Send Message</span></a>
  </div>
</nav>



    <form method="post" class="form-container">    
        <h2 class="page-title">Communicate with Sellers/Buyers</h2>
        <label class="form-label">Recipient:</label>
        <select name="receiverID" class="form-select" required>
            <option value="">-- Select Recipient --</option>
            <?php
            if ($users && $users->num_rows > 0) {
                while ($row = $users->fetch_assoc()) {
                    echo "<option value='".$row['userID']."'>".$row['username']." (".$row['role'].")</option>";
                }
            }
            ?>
        </select>

        <input type="hidden" name="roleTo" value="">

        <label class="form-label">Subject:</label>
        <input type="text" name="subject" class="form-input" required>

        <label class="form-label">Message:</label>
        <textarea name="body" class="form-textarea" required></textarea>

        <input type="submit" value="Send Message" class="btn-cart">
    </form>

    <script>
        // Auto-fill roleTo based on dropdown selection
        document.querySelector("select[name='receiverID']").addEventListener("change", function() {
            var selectedOption = this.options[this.selectedIndex].text;
            if (selectedOption.includes("(Seller)")) {
                document.querySelector("input[name='roleTo']").value = "Seller";
            } else if (selectedOption.includes("(Customer)")) {
                document.querySelector("input[name='roleTo']").value = "Customer";
            }
        });
    </script>
</body>

 <footer>
  <div class="footer-links">
    <h4>Quick Links</h4>
    <p>
      <a href="contact.php">Contact Us</a> | 
      <a href="about.php">About</a> | 
      <a href="privacy.php">Privacy Policy</a> | 
      <a href="faq.php">FAQ</a> | 
      <a href="returns.php">Returns & Exchanges</a>
    </p>
  </div>

  <div class="footer-info">
    <h4>Store Info</h4>
    <p>📍 Johannesburg, South Africa</p>
    <p>📧 support@pastimes.com</p>
    <p>☎ +27 11 123 4567</p>
    <p>🕒 Mon–Fri: 9am – 6pm | Sat: 10am – 4pm</p>
  </div>

  <div class="footer-social">
    <h4>Follow Us</h4>
    <a href="https://www.facebook.com">Facebook</a>
    <a href="https://www.instagram.com">Instagram</a>
    <a href="https://www.twitter.com">Twitter</a>
  </div>

  <div class="footer-bottom">
    <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
  </div>
</footer>
</html>
