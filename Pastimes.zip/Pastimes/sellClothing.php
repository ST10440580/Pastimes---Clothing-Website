<?php
include("config/DBConn.php");
session_start();

// ✅ Guard clause: make sure seller is logged in
if (!isset($_SESSION['userID'])) {
    die("<h2 style='color:red; text-align:center;'>You must be logged in as a Seller to submit a request.</h2>");
}

$sellerID = intval($_SESSION['userID']); // ensure integer

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $brand = $_POST['brand'];
    $description = $_POST['description'];
    $condition = $_POST['item_condition'];
    $price = $_POST['item_price'];

    // Handle image upload
    $targetDir = "images/";
    $fileName = basename($_FILES["image"]["name"]);
    $targetFilePath = $targetDir . $fileName;

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
        // Insert request into tblsellrequests
        $sql = "INSERT INTO tblsellrequests 
                (sellerID, name, brand, description, item_condition, item_price, image, status)
                VALUES ($sellerID, '$name', '$brand', '$description', '$condition', '$price', '$fileName', 'Pending')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Request submitted successfully!'); window.location.href='sellClothing.php';</script>";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "<h3 style='color:red; text-align:center;'>Image upload failed. Please try again.</h3>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sell Clothing</title>
    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
    
    <nav class="seller-nav">
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes Seller Portal</span>
  </div>
  <div class="nav-links">
    <a href="index.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    <a href="sellClothing.php"><i class="fas fa-tshirt"></i><span>Sell Clothing</span></a>
    <a href="sellerDashboard.php"><i class="fas fa-box-open"></i><span>My Products</span></a>
  </div>
</nav>

    <!-- Informative section for sellers -->
    <div class="about">
        <h2>How Selling Works</h2>
        <p>
            Welcome to the Seller Portal! Here you can submit clothing items you wish to sell. 
            Please provide accurate details including brand, condition, and a clear image of the item.
        </p>
        <p>
            Once submitted, your request will be marked as <strong>Pending</strong>. 
            An Administrator will review your submission to ensure the item meets our quality standards. 
            If approved, your clothing will be added to the main shop and made available to customers.
        </p>
        <p>
            If your request is rejected, you will be notified and can resubmit with updated details. 
            Remember: clear images and honest descriptions increase your chances of approval.
        </p>
    </div>

    <!-- Seller request form -->
    <form method="post" enctype="multipart/form-data">
        <h2>Submit Clothing Request</h2>
        <label>Name:</label>
        <input type="text" name="name" required><br>

        <label>Brand:</label>
        <input type="text" name="brand" required><br>

        <label>Description:</label>
        <textarea name="description" required></textarea><br>

        <label>Condition:</label>
        <select name="item_condition" required>
            <option value="New">New</option>
            <option value="Used">Used</option>
        </select><br>

        <label>Price:</label>
        <input type="number" step="0.01" name="item_price" required><br>

        <label>Image:</label>
        <input type="file" name="image" accept="image/*" required><br>

        <input type="submit" value="Submit Request">
    </form>
</body>

<footer>
  <div class="footer-links">
    <h4>Quick Links</h4>
    <p>
      <a href="contact.php">Contact Us</a> | 
      <a href="about.php">About</a> | 
      <a href="privacy.php">Privacy Policy</a> | 
      <a href="faq.php">FAQ</a> | 
      <a href="returns.php">Returns & Exchanges</a>
    </p>
  </div>

  <div class="footer-info">
    <h4>Store Info</h4>
    <p>📍 Johannesburg, South Africa</p>
    <p>📧 support@pastimes.com</p>
    <p>☎ +27 11 123 4567</p>
    <p>🕒 Mon–Fri: 9am – 6pm | Sat: 10am – 4pm</p>
  </div>

  <div class="footer-social">
    <h4>Follow Us</h4>
    <a href="https://www.facebook.com">Facebook</a>
    <a href="https://www.instagram.com">Instagram</a>
    <a href="https://www.twitter.com">Twitter</a>
  </div>

  <div class="footer-bottom">
    <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
  </div>
</footer>
</html>
