<?php
include("config/DBConn.php");

$id       = intval($_POST['userID']);
$fullName = $_POST['fullName'];
$email    = $_POST['email'];
$username = $_POST['username'];

$sql = "UPDATE tblUser SET fullName='$fullName', email='$email', username='$username' WHERE userID=$id";
$conn->query($sql);

echo "Customer updated successfully. <a href='adminDashboard.php'>Back</a>";
?>
