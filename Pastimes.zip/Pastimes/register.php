 <nav>
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes</span>
  </div>
  <div class="nav-links">
    <a href="index.php"><i class="fas fa-home"></i><span>Home</span></a> 
    <a href="register.php"><i class="fas fa-user-plus"></i><span>Register</span></a>
    <a href="login.php"><i class="fas fa-sign-in-alt"></i><span>Login</span></a>
    <a href="adminLogin.php"><i class="fas fa-user-shield"></i><span>Admin</span></a>
    <a href="sellerLogin.php"><i class="fas fa-store"></i><span>Seller</span></a>
  </div>
</nav>

<?php
//implemented this to ensure wepage connection with the database
include("config/DBConn.php");


//Checks if form is submitted into the database
if ($_SERVER["REQUEST_METHOD"] == "POST") {



//Ensures field are added to the database
    $fullName = $conn->real_escape_string($_POST['fullName']);
    $email    = $conn->real_escape_string($_POST['email']);
    $username = $conn->real_escape_string($_POST['username']);
    $password = md5($conn->real_escape_string($_POST['password']));//hashed password 



    // Check if username or email already exists
    $check = $conn->query("SELECT * FROM tbluser WHERE email='$email' OR username='$username'");
    if ($check->num_rows > 0) {
        echo "User already exists. Try another email or username.";



    //Insert new user into the database if user does not exist
    } else {
        $sql = "INSERT INTO tbluser (fullName, email, username, password, verified)
                VALUES ('$fullName', '$email', '$username', '$password', 0)";


//Display error meesage or if there is a error within our database 
        if ($conn->query($sql) === TRUE) {
            echo "Registration successful! Waiting for admin verification.";
            
        } else {
            echo "Error: " . $conn->error;
        }
    }
}
?>



<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
    

  

    

    <form method="POST" action="register.php">
        <h2>Create Account</h2>
        Full Name: <input type="text" name="fullName" required><br><br>
        Email: <input type="email" name="email" required><br><br>
        Username: <input type="text" name="username" required><br><br>
        Password: <input type="password" name="password" required><br><br>
        <input type="submit" value="Register">
    </form>
  <!-- About Section -->
    <section class="about">
        <h2>Note:</h2>
        <p>Try logging in to see if your registration has been verified.</p>
    </section>
</body>


<footer>
  <div class="footer-links">
    <h4>Quick Links</h4>
    <p>
      <a href="contact.php">Contact Us</a> | 
      <a href="about.php">About</a> | 
      <a href="privacy.php">Privacy Policy</a> | 
      <a href="faq.php">FAQ</a> | 
      <a href="returns.php">Returns & Exchanges</a>
    </p>
  </div>

  <div class="footer-info">
    <h4>Store Info</h4>
    <p>📍 Johannesburg, South Africa</p>
    <p>📧 support@pastimes.com</p>
    <p>☎ +27 11 123 4567</p>
    <p>🕒 Mon–Fri: 9am – 6pm | Sat: 10am – 4pm</p>
  </div>

  <div class="footer-social">
    <h4>Follow Us</h4>
    <a href="https://www.facebook.com">Facebook</a>
    <a href="https://www.instagram.com">Instagram</a>
    <a href="https://www.twitter.com">Twitter</a>
  </div>

  <div class="footer-bottom">
    <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
  </div>
</footer>

</html>
