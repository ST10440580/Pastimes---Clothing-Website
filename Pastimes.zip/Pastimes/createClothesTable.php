<?php
include("config/DBConn.php");

$sql = "DROP TABLE IF EXISTS tblclothes";
$conn->query($sql);

$sql = "CREATE TABLE tblclothes (
    clothesID INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    size VARCHAR(10) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL
)";
$conn->query($sql);

$file = fopen("clothesData.txt", "r");
if ($file) {
    while (($line = fgets($file)) !== false) {
        $data = explode(",", trim($line));
        if (count($data) == 5) {
            $name     = $conn->real_escape_string($data[0]);
            $category = $conn->real_escape_string($data[1]);
            $size     = $conn->real_escape_string($data[2]);
            $price    = $conn->real_escape_string($data[3]);
            $stock    = $conn->real_escape_string($data[4]);

            $sql = "INSERT INTO tblclothes (name, category, size, price, stock)
                    VALUES ('$name', '$category', '$size', '$price', '$stock')";
            $conn->query($sql);
        }
    }
    fclose($file);
}

echo "tblclothes recreated and data loaded successfully!";
?>
