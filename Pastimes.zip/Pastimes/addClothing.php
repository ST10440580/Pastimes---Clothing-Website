<?php
include("config/DBConn.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $category = $_POST['category'];
    $size = $_POST['size'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    // Handle image upload
    $targetDir = "images/";
    $fileName = basename($_FILES["image"]["name"]);
    $targetFilePath = $targetDir . $fileName;

    // Move uploaded file to images folder
    if(move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)){
        // Insert into database
        $sql = "INSERT INTO tblclothes (name, category, size, price, stock, image) 
                VALUES ('$name', '$category', '$size', '$price', '$stock', '$fileName')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Clothing item added successfully!'); window.location.href='manageClothing.php';</script>";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "Error uploading image.";
    }
}
?>
