<?php
session_start();
include("config/DBConn.php");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Cart</title>
    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
  

<nav class="store-nav">
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes</span>
  </div>
  <div class="nav-links">
    <a href="index.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    <a href="products.php"><i class="fas fa-tshirt"></i><span>Products</span></a>
    <a href="viewCart.php"><i class="fas fa-shopping-cart"></i><span>Cart</span></a>
  </div>
</nav>


    <h2>Your Cart</h2>

<?php

//Check if users cart is empty
if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
    echo "<p class='empty-cart'>Cart is empty.</p>";
} else {


//Display what the user added to thier cart
    $ids = implode(",", $_SESSION['cart']);
    $result = $conn->query("SELECT * FROM tblclothes WHERE clothesID IN ($ids)");


    //How the cart table id gonna look like
    echo "<table class='cart-table'>";
    echo "<tr>
            <th>Image</th>
            <th>Name</th>
            <th>Category</th>
            <th>Size</th>
            <th>Price</th>
            <th>Action</th>
          </tr>";
    $total = 0;


    //
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        // Product image
        echo "<td>";
        if (!empty($row['image'])) {
            echo "<img src='images/".$row['image']."' alt='".$row['name']."' class='product-img'>";
        } else {
            echo "No image";
        }
        echo "</td>";

        echo "<td>".$row['name']."</td>";
        echo "<td>".$row['category']."</td>";
        echo "<td>".$row['size']."</td>";
        echo "<td>R".$row['price']."</td>";
        echo "<td><a href='removeFromCart.php?id=".$row['clothesID']."' class='btn-remove'>Remove</a></td>";
        echo "</tr>";
        $total += $row['price'];
    }

//Show total of the.
    echo "</table>";
    echo "<p class='cart-total'>Total: R".$total."</p>";
    echo "<a href='deliveryDetails.php' class='btn-view'>Place Order</a>";
}
?>



<footer>
  <div class="footer-links">
    <h4>Quick Links</h4>
    <p>
      <a href="contact.php">Contact Us</a> | 
      <a href="about.php">About</a> | 
      <a href="privacy.php">Privacy Policy</a> | 
      <a href="faq.php">FAQ</a> | 
      <a href="returns.php">Returns & Exchanges</a>
    </p>
  </div>

  <div class="footer-info">
    <h4>Store Info</h4>
    <p>📍 Johannesburg, South Africa</p>
    <p>📧 support@pastimes.com</p>
    <p>☎ +27 11 123 4567</p>
    <p>🕒 Mon–Fri: 9am – 6pm | Sat: 10am – 4pm</p>
  </div>

  <div class="footer-social">
    <h4>Follow Us</h4>
    <a href="https://www.facebook.com">Facebook</a>
    <a href="https://www.instagram.com">Instagram</a>
    <a href="https://www.twitter.com">Twitter</a>
  </div>

  <div class="footer-bottom">
    <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
  </div>
</footer>
</body>
</html>
