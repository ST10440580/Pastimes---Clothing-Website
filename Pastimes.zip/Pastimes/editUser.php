<?php
include("config/DBConn.php");

$id = intval($_GET['id']);
$result = $conn->query("SELECT * FROM tblUser WHERE userID=$id");
$user = $result->fetch_assoc();
?>

<h3>Edit Customer</h3>
<form method="post" action="updateUser.php">
    <input type="hidden" name="userID" value="<?php echo $user['userID']; ?>">
    <label>Full Name:</label><input type="text" name="fullName" value="<?php echo $user['fullName']; ?>" required><br>
    <label>Email:</label><input type="email" name="email" value="<?php echo $user['email']; ?>" required><br>
    <label>Username:</label><input type="text" name="username" value="<?php echo $user['username']; ?>" required><br>
    <input type="submit" value="Update Customer">
</form>
