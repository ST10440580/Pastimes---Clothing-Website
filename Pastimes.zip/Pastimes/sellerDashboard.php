<?php
include("config/DBConn.php");
session_start();

// ✅ Only Sellers can access
if (!isset($_SESSION['userID']) || $_SESSION['role'] !== 'Seller') {
    die("<h2 style='color:red; text-align:center;'>Access denied. Only Sellers can view this page.</h2>");
}

$sellerID = intval($_SESSION['userID']);

// Fetch seller requests
$sql = "SELECT * FROM tblsellrequests WHERE sellerID = $sellerID ORDER BY requestID DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    
    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
    
  <nav class="seller-nav">
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes Seller Portal</span>
  </div>
  <div class="nav-links">
    <a href="sellClothing.php"><i class="fas fa-plus-circle"></i><span>Submit New Request</span></a>
    <a href="inbox.php"><i class="fas fa-envelope"></i><span>View Messages</span></a>
    <a href="index.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
  </div>
</nav>


    <h2>Your Clothing Requests</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Brand</th>
            <th>Description</th>
            <th>Condition</th>
            <th>Price</th>
            <th>Image</th>
            <th>Status</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>".$row['requestID']."</td>";
                echo "<td>".$row['name']."</td>";
                echo "<td>".$row['brand']."</td>";
                echo "<td>".$row['description']."</td>";
                echo "<td>".$row['item_condition']."</td>";
                echo "<td>".$row['item_price']."</td>";
                echo "<td><img src='images/".$row['image']."' class='product-img'></td>";
                echo "<td><strong>".$row['status']."</strong></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='8' style='text-align:center;'>No requests found.</td></tr>";
        }
        ?>
    </table>
</body>

<footer>
  <div class="footer-links">
    <h4>Quick Links</h4>
    <p>
      <a href="contact.php">Contact Us</a> | 
      <a href="about.php">About</a> | 
      <a href="privacy.php">Privacy Policy</a> | 
      <a href="faq.php">FAQ</a> | 
      <a href="returns.php">Returns & Exchanges</a>
    </p>
  </div>

  <div class="footer-info">
    <h4>Store Info</h4>
    <p>📍 Johannesburg, South Africa</p>
    <p>📧 support@pastimes.com</p>
    <p>☎ +27 11 123 4567</p>
    <p>🕒 Mon–Fri: 9am – 6pm | Sat: 10am – 4pm</p>
  </div>

  <div class="footer-social">
    <h4>Follow Us</h4>
    <a href="https://www.facebook.com">Facebook</a>
    <a href="https://www.instagram.com">Instagram</a>
    <a href="https://www.twitter.com">Twitter</a>
  </div>

  <div class="footer-bottom">
    <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
  </div>
</footer>
</html>
