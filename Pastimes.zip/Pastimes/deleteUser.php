<?php
include("config/DBConn.php");

$id = intval($_GET['id']);
$sql = "DELETE FROM tblUser WHERE userID=$id";
$conn->query($sql);

echo "Customer deleted successfully. <a href='adminDashboard.php'>Back</a>";
?>
