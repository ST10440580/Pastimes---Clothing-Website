






<?php
include("config/DBConn.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $role = trim($_POST['role']);

    // Hash password with MD5 (same as your login logic)
    $hashedPassword = md5($password);

    // Prevent duplicate usernames or emails
    $check = $conn->query("SELECT * FROM tblAdmin WHERE username='$username' OR email='$email'");
    if ($check->num_rows > 0) {
        $message = "Username or email already exists!";
    } else {
        $sql = "INSERT INTO tblAdmin (username, email, password, role)
                VALUES ('$username', '$email', '$hashedPassword', '$role')";
        if ($conn->query($sql) === TRUE) {
            $message = "Admin registered successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Registration</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <form method="POST" action="">
        <h2>Admin Registeration</h2>
        <input type="text" name="username" placeholder="Username" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <select name="role" required>
            <option value="Admin">Admin</option>
            <option value="Moderator">Moderator</option>
            <option value="Editor">Editor</option>
            <option value="SuperAdmin">SuperAdmin</option>
        </select>
        <input type="submit" value="Register">
        <div class="message"><?php echo $message; ?></div>

        <a href="adminLogin.php">Login</a>
    </form>
</body>
</html>


