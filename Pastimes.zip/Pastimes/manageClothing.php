<!DOCTYPE html>
<html>
<head>
    <title>Manage Clothing</title>
    <link rel="stylesheet" href="css/style.css"> 
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
   
   <nav class="admin-nav">
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes Admin</span>
  </div>
  <div class="nav-links">
    <a href="index.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    <a href="adminDashboard.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
  </div>
</nav>


    <h2>Add New Clothing Item</h2>
    <form method="post" action="addClothing.php" enctype="multipart/form-data">
        <label>Name:</label><input type="text" name="name" required><br>
        <label>Category:</label><input type="text" name="category" required><br>
        <label>Size:</label><input type="text" name="size" required><br>
        <label>Price:</label><input type="number" step="0.01" name="price" required><br>
        <label>Stock:</label><input type="number" name="stock" required><br>
        <label>Image:</label><input type="file" name="image" accept="image/*" required><br>
        <input type="submit" value="Add Clothing Item">
    </form>

    <?php
    include("config/DBConn.php");

    // Show all clothing items
    $result = $conn->query("SELECT * FROM tblclothes");

    echo "<center><h2>Clothing Management</h2></center>";
    echo "<table>"; // styled by your CSS

    echo "<tr>
            <th>ID</th>
            <th>Name</th>
            <th>Category</th>
            <th>Size</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Image</th>
            <th>Actions</th>
          </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row['clothesID']."</td>";
        echo "<td>".$row['name']."</td>";
        echo "<td>".$row['category']."</td>";
        echo "<td>".$row['size']."</td>";
        echo "<td>".$row['price']."</td>";
        echo "<td>".$row['stock']."</td>";

        // If you store full path in DB (e.g., 'images/shirt.jpg'), just echo directly:
        // echo "<td><img src='".$row['image']."' class='product-img'></td>";

        // If you store only filename (e.g., 'shirt.jpg'), prepend folder:
        echo "<td><img src='images/".$row['image']."' class='product-img'></td>";

        echo "<td>
                <a href='editClothing.php?id=".$row['clothesID']."' class='btn-cart'>Edit</a> 
                <a href='deleteClothing.php?id=".$row['clothesID']."' class='btn-remove'
                   onclick=\"return confirm('Are you sure you want to delete this item?');\">Delete</a>
              </td>";
        echo "</tr>";
    }
    echo "</table>";
    ?>
</body>
</html>
