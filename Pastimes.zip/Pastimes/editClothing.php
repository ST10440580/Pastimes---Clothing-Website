<?php
include("config/DBConn.php"); // adjust path if needed

// Get clothing item by ID safely
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$result = $conn->query("SELECT * FROM tblclothes WHERE clothesID=$id");

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    die("<h2 style='color:red; text-align:center;'>Clothing item not found.</h2>");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name     = $_POST['name'];
    $category = $_POST['category'];
    $size     = $_POST['size'];
    $price    = $_POST['price'];
    $stock    = $_POST['stock'];

    // Handle image upload
    if (!empty($_FILES["image"]["name"])) {
        $targetDir = "images/"; // use same folder as display
        // Create unique filename to avoid overwriting
        $fileName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFilePath = $targetDir . $fileName;

        // Validate file type
        $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
        $allowedTypes = ['jpg','jpeg','png','gif'];
        if (in_array($fileType, $allowedTypes)) {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
                // success
            } else {
                die("<p style='color:red;'>Error uploading image. Check folder permissions.</p>");
            }
        } else {
            die("<p style='color:red;'>Invalid file type. Only JPG, JPEG, PNG, GIF allowed.</p>");
        }
    } else {
        $fileName = $row['image']; // keep old image
    }

    // Update record
    $sql = "UPDATE tblclothes 
            SET name='$name', category='$category', size='$size', price='$price', stock='$stock', image='$fileName'
            WHERE clothesID=$id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Clothing item updated successfully!'); window.location.href='manageClothing.php';</script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Clothing</title>
    <link rel="stylesheet" href="css/style.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
    
<nav class="admin-nav">
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes Admin</span>
  </div>
  <div class="nav-links">
    <a href="manageClothing.php"><i class="fas fa-tshirt"></i><span>Back to Clothing Management</span></a>
  </div>
</nav>

<form method="post" enctype="multipart/form-data">
    <h2>Edit Clothing Item</h2>

    <label>Name:</label>
    <input type="text" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" required>

    <label>Category:</label>
    <input type="text" name="category" value="<?php echo htmlspecialchars($row['category']); ?>" required>

    <label>Size:</label>
    <input type="text" name="size" value="<?php echo htmlspecialchars($row['size']); ?>" required>

    <label>Price:</label>
    <input type="number" step="0.01" name="price" value="<?php echo htmlspecialchars($row['price']); ?>" required>

    <label>Stock:</label>
    <input type="number" name="stock" value="<?php echo htmlspecialchars($row['stock']); ?>" required>

    <label>Image:</label>
    <input type="file" name="image" accept="image/*">
    <br>
    <img src="images/<?php echo htmlspecialchars($row['image']); ?>" 
         class="product-img" width="120" alt="Clothing Image">

    <input type="submit" value="Update Clothing Item">
</form>
</body>
</html>
