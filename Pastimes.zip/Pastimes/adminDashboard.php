
<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
    
   <nav>
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes Admin</span>
  </div>
  <div class="nav-links">
    <a href="index.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    <a href="manageOrders.php"><i class="fas fa-box"></i><span>Manage Orders</span></a>
    <a href="manageClothing.php"><i class="fas fa-tshirt"></i><span>Manage Clothing</span></a>
    <a href="manageRequests.php"><i class="fas fa-tasks"></i><span>Clothing Requests</span></a>
    <a href="adminCommunicate.php"><i class="fas fa-envelope"></i><span>Send Message</span></a>
  </div>
</nav>

    <h2>Add new customer</h2>


<form method="post" action="addUser.php">
    <label>Full Name:</label><input type="text" name="fullName" required><br>
    <label>Email:</label><input type="email" name="email" required><br>
    <label>Username:</label><input type="text" name="username" required><br>
    <label>Password:</label><input type="password" name="password" required><br>
    <input type="submit" value="Add Customer">
    
</form>





<?php
include("config/DBConn.php");

// Show all users
$result = $conn->query("SELECT * FROM tblUser");

echo "<center><h2>Customer Management</h2></center>";
echo "<center><table border='1'>";
echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Username</th><th>Verified</th><th>Actions</th></tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>".$row['userID']."</td>";
    echo "<td>".$row['fullName']."</td>";
    echo "<td>".$row['email']."</td>";
    echo "<td>".$row['username']."</td>";
    echo "<td>".$row['verified']."</td>";
    echo "<td>
            <a href='verifyUser.php?id=".$row['userID']."'>Verify</a> |
            <a href='editUser.php?id=".$row['userID']."'>Edit</a> |
            <a href='deleteUser.php?id=".$row['userID']."'>Delete</a>
          </td>";
    echo "</tr>";
}
echo "</table></center>";

?>
 <footer>
  <div class="footer-links">
    <h4>Quick Links</h4>
    <p>
      <a href="contact.php">Contact Us</a> | 
      <a href="about.php">About</a> | 
      <a href="privacy.php">Privacy Policy</a> | 
      <a href="faq.php">FAQ</a> | 
      <a href="returns.php">Returns & Exchanges</a>
    </p>
  </div>

  <div class="footer-info">
    <h4>Store Info</h4>
    <p>📍 Johannesburg, South Africa</p>
    <p>📧 support@pastimes.com</p>
    <p>☎ +27 11 123 4567</p>
    <p>🕒 Mon–Fri: 9am – 6pm | Sat: 10am – 4pm</p>
  </div>

  <div class="footer-social">
    <h4>Follow Us</h4>
    <a href="https://www.facebook.com">Facebook</a>
    <a href="https://www.instagram.com">Instagram</a>
    <a href="https://www.twitter.com">Twitter</a>
  </div>

  <div class="footer-bottom">
    <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
  </div>
</footer>