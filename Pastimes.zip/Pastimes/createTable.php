<?php
include("config/DBConn.php");

// Drop table if it exists
$sql = "DROP TABLE IF EXISTS tblUser";
$conn->query($sql);

// Create table again
$sql = "CREATE TABLE tblUser (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    fullName VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    verified TINYINT(1) DEFAULT 0
)";
$conn->query($sql);

// Load data from userData.txt
$file = fopen("userData.txt", "r");
if ($file) {
    while (($line = fgets($file)) !== false) {
        $data = explode(",", trim($line));
        if (count($data) == 4) {
            $fullName = $conn->real_escape_string($data[0]);
            $email    = $conn->real_escape_string($data[1]);
            $username = $conn->real_escape_string($data[2]);
            $password = $conn->real_escape_string($data[3]);

            $sql = "INSERT INTO tblUser (fullName, email, username, password, verified)
                    VALUES ('$fullName', '$email', '$username', MD5('$password'), 0)";
            $conn->query($sql);
        }
    }
    fclose($file);
}

echo "tblUser recreated and data loaded successfully!";
?>
