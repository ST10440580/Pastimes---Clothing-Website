<?php
session_start();
include("config/DBConn.php");


//Get id for the piece of clothing 
$id = intval($_GET['id']);


//ensures clothing items are added into cart 
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}
$_SESSION['cart'][] = $id;

?>
<!DOCTYPE html>
<html>
<head>
    <title>Item Added</title>
    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
    
   <nav>
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes</span>
  </div>
  <div class="nav-links">
    <a href="index.php"><i class="fas fa-home"></i><span>Home</span></a>
    <a href="products.php"><i class="fas fa-tshirt"></i><span>Products</span></a>
    <a href="viewCart.php"><i class="fas fa-shopping-cart"></i><span>View Cart</span></a>
  </div>
</nav>


    <section class="about">
        <h2>Item Added to Cart!</h2>
        <p>Your product has been successfully added to the shopping cart.</p>
        <a href="products.php" class="btn-cart">Back to Products</a>
        <a href="viewCart.php" class="btn-view">View Cart</a>
    </section>

    <footer>
  <div class="footer-links">
    <h4>Quick Links</h4>
    <p>
      <a href="contact.php">Contact Us</a> | 
      <a href="about.php">About</a> | 
      <a href="privacy.php">Privacy Policy</a> | 
      <a href="faq.php">FAQ</a> | 
      <a href="returns.php">Returns & Exchanges</a>
    </p>
  </div>

  <div class="footer-info">
    <h4>Store Info</h4>
    <p>📍 Johannesburg, South Africa</p>
    <p>📧 support@pastimes.com</p>
    <p>☎ +27 11 123 4567</p>
    <p>🕒 Mon–Fri: 9am – 6pm | Sat: 10am – 4pm</p>
  </div>

  <div class="footer-social">
    <h4>Follow Us</h4>
    <a href="https://www.facebook.com">Facebook</a>
    <a href="https://www.instagram.com">Instagram</a>
    <a href="https://www.twitter.com">Twitter</a>
  </div>

  <div class="footer-bottom">
    <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
  </div>
</footer>
</body>
</html>
