<?php
include("config/DBConn.php");
session_start();



// Ensures only authorized admin roles can access
$allowedRoles = ['admin','superadmin','manager','staff','moderator','editor'];

if (!isset($_SESSION['adminID']) || !in_array(strtolower($_SESSION['role']), $allowedRoles)) {
    die("<h2 style='color:red; text-align:center;'>Access denied. Only Admin roles can view this page.</h2>");
}


// Handle Approve/Reject actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $requestID = intval($_GET['id']);
    $action = $_GET['action'];

    if ($action === 'approve') {
        // Fetch request details
        $req = $conn->query("SELECT * FROM tblsellrequests WHERE requestID=$requestID")->fetch_assoc();

        if ($req) {
            // Insert into tblclothes
            $sql = "INSERT INTO tblclothes (name, category, size, price, stock, image)
                    VALUES ('".$req['name']."', '".$req['brand']."', 'N/A', '".$req['item_price']."', 1, '".$req['image']."')";
            $conn->query($sql);

            // Update request status
            $conn->query("UPDATE tblsellrequests SET status='Approved' WHERE requestID=$requestID");
        }
    } elseif ($action === 'reject') {
        $conn->query("UPDATE tblsellrequests SET status='Rejected' WHERE requestID=$requestID");
    }

    echo "<script>alert('Action completed successfully!'); window.location.href='manageRequests.php';</script>";
    exit;
}

// Fetch all requests
$result = $conn->query("SELECT * FROM tblsellrequests ORDER BY requestID DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Seller Requests</title>
    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
   
   <nav class="admin-nav">
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes Admin</span>
  </div>
  <div class="nav-links">
    <a href="adminDashboard.php"><i class="fas fa-tachometer-alt"></i><span>Back to Dashboard</span></a>
    <a href="index.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
  </div>
</nav>


    <h2>Seller Requests</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Seller ID</th>
            <th>Name</th>
            <th>Brand</th>
            <th>Description</th>
            <th>Condition</th>
            <th>Price</th>
            <th>Image</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>".$row['requestID']."</td>";
                echo "<td>".$row['sellerID']."</td>";
                echo "<td>".$row['name']."</td>";
                echo "<td>".$row['brand']."</td>";
                echo "<td>".$row['description']."</td>";
                echo "<td>".$row['item_condition']."</td>";
                echo "<td>".$row['item_price']."</td>";
                echo "<td><img src='images/".$row['image']."' class='product-img'></td>";
                echo "<td><strong>".$row['status']."</strong></td>";
                echo "<td>";
                if ($row['status'] === 'Pending') {
                    echo "<a href='manageRequests.php?action=approve&id=".$row['requestID']."' class='btn-cart'>Approve</a> ";
                    echo "<a href='manageRequests.php?action=reject&id=".$row['requestID']."' class='btn-remove'
                           onclick=\"return confirm('Reject this request?');\">Reject</a>";
                } else {
                    echo "No actions available";
                }
                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='10' style='text-align:center;'>No requests found.</td></tr>";
        }
        ?>
    </table>
</body>
</html>
