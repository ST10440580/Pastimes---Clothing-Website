<?php
include("config/DBConn.php");
session_start();

$userID = $_SESSION['userID']; 
$role = $_SESSION['role'];

$sql = "SELECT * FROM tblmessages WHERE receiverID=? AND roleTo=? ORDER BY sentAt DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $userID, $role);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Inbox</title>

    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>

<nav class="seller-nav">
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes Seller Portal</span>
  </div>
  <div class="nav-links">
    <a href="sellClothing.php"><i class="fas fa-plus-circle"></i><span>Submit Request</span></a>
    <a href="inbox.php"><i class="fas fa-envelope"></i><span>Inbox</span></a>
    <a href="index.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
  </div>
</nav>
<body>
    <h2 class="page-title">📥 Your Inbox</h2>
    <div class="inbox-container">
        <table class="inbox-table">
            <thead>
                <tr>
                    <th>From</th>
                    <th>Subject</th>
                    <th>Message</th>
                    <th>Status</th>
                    <th>Sent At</th>
                </tr>
            </thead>
            <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    // Add a class for unread messages
                    $rowClass = ($row['status'] === 'Unread') ? 'unread' : 'read';

                    echo "<tr class='".$rowClass."'>
                            <td class='inbox-from'>".$row['roleFrom']."</td>
                            <td class='inbox-subject'><strong>".$row['subject']."</strong></td>
                            <td class='inbox-message'>".$row['body']."</td>
                            <td class='inbox-status ".$row['status']."'>".$row['status']."</td>
                            <td class='inbox-date'>".date("Y-m-d H:i", strtotime($row['sentAt']))."</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='5' class='inbox-empty'>No messages found.</td></tr>";
            }
            ?>
            </tbody>
        </table>
    </div>
</body>


<!-- Footer -->
<footer>
  <div class="footer-links">
    <h4>Quick Links</h4>
    <p>
      <a href="contact.php">Contact Us</a> | 
      <a href="about.php">About</a> | 
      <a href="privacy.php">Privacy Policy</a> | 
      <a href="faq.php">FAQ</a> | 
      <a href="returns.php">Returns & Exchanges</a>
    </p>
  </div>

  <div class="footer-info">
    <h4>Store Info</h4>
    <p>📍 Johannesburg, South Africa</p>
    <p>📧 support@pastimes.com</p>
    <p>☎ +27 11 123 4567</p>
    <p>🕒 Mon–Fri: 9am – 6pm | Sat: 10am – 4pm</p>
  </div>

  <div class="footer-social">
    <h4>Follow Us</h4>
    <a href="https://www.facebook.com">Facebook</a>
    <a href="https://www.instagram.com">Instagram</a>
    <a href="https://www.twitter.com">Twitter</a>
  </div>

  <div class="footer-bottom">
    <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
  </div>
</footer>
</html>
