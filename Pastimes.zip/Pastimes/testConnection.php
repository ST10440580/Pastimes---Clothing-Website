<?php
include("config/DBConn.php");
echo "Connected successfully as root to ClothingStore!";
?>
