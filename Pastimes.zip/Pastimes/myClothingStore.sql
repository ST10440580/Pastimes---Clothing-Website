-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: May 03, 2026 at 01:50 PM
-- Server version: 11.4.9-MariaDB
-- PHP Version: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clothingstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

DROP TABLE IF EXISTS `tbladmin`;
CREATE TABLE IF NOT EXISTS `tbladmin` (
  `adminID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'Admin',
  PRIMARY KEY (`adminID`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`adminID`, `username`, `email`, `password`, `role`) VALUES
(1, 'admin1', 'admin@example.com', '6805ebbe7015b2d882e47dd1f12a7632', 'superadmin'),
(2, 'manager1', 'manager@example.com', '2ba337b4d78d328e29750baa3b45865f', 'manager'),
(3, 'staff1', 'staff@example.com', 'd356d165a2ff29bc2dc36248daa2932d', 'staff'),
(4, 'admin2', 'admin2@example.com', 'bec37ae47461cf698808746aefeda77e', 'superadmin'),
(5, 'manager2', 'manager2@example.com', '6957cd482bb903f8e455a6754505adec', 'manager'),
(6, 'admin26', 'lerato.admin@example.com', '89f6d7cc0bf8ffb3b3041d7f12f5b497', 'Admin'),
(7, 'admin27', 'siyabonga.admin@example.com', '9d1daca71ba6c796f015e4610d4ed1ad', 'Moderator'),
(8, 'admin28', 'nomvula.admin@example.com', '4046f9f0d2429c7b2ca274a216792770', 'Editor'),
(9, 'admin29', 'andre.admin@example.com', '767c968e9cf1fbe65901a5df56eac149', 'SuperAdmin'),
(10, 'admin30', 'tasneem.admin@example.com', '1893c20adbc8edde70d4327d446aa989', 'Admin'),
(11, 'admin31', 'kgomotso.admin@example.com', '78d87fadd83e612e2b6bbd402f08033c', 'Moderator'),
(12, 'admin32', 'phindile.admin@example.com', '6c48ca1db62be13873870816e2ea4144', 'Editor'),
(13, 'admin33', 'brandon.admin@example.com', '867deb11002c0a8b8058204f4c31f0aa', 'SuperAdmin'),
(14, 'admin34', 'noluthando.admin@example.com', '627f988851e7d99af65f872bba8431a9', 'Admin'),
(15, 'admin35', 'musa.admin@example.com', '99c3c531755154ad28d9677a3a841879', 'Moderator'),
(16, 'admin36', 'yusuf.admin@example.com', '80c146b6b4fa9f962be12ff2bbd497ee', 'Editor'),
(17, 'admin37', 'carmen.admin@example.com', 'b938bb392e52150e02ed9bfc32c89958', 'SuperAdmin'),
(18, 'admin38', 'thuli.admin@example.com', 'ea09d0297f0f97d3d5b7f7db43669382', 'Admin'),
(19, 'admin39', 'dumisani.admin@example.com', 'f0f93248b652119311820a90f278e3d6', 'Moderator'),
(20, 'admin40', 'portia.admin@example.com', '811d735d70f8bdc9757a3db5cbeb4cdc', 'Editor'),
(21, 'admin41', 'shaun.admin@example.com', '4a7e6f19596310694bd3aa7b6a277990', 'SuperAdmin'),
(22, 'admin42', 'precious.admin@example.com', '4e221579617742dea61bdd8f103f4e99', 'Admin'),
(23, 'admin43', 'bongani.admin@example.com', 'f4b4450a714127ffda711d5265078cb4', 'Moderator'),
(24, 'admin44', 'nadia.admin@example.com', 'a589dda0a52455f4857ae2c00deda2a7', 'Editor'),
(25, 'admin45', 'samantha.admin@example.com', '83940b12d48b9667f3f2ec4b559b8d63', 'SuperAdmin'),
(26, 'admin46', 'thandeka.admin@example.com', '813719baa42b25564b9e8f7d0b80f3a7', 'Admin'),
(27, 'admin47', 'vusi.admin@example.com', '552a48baa07411b3c26645a765318511', 'Moderator'),
(28, 'admin48', 'megan.admin@example.com', '38d78538e52e8b89d99c7d2a3e75931c', 'Editor'),
(29, 'admin49', 'ronald.admin@example.com', 'c64a46c31e93c0cd46d5ac36870bf732', 'SuperAdmin'),
(30, 'admin50', 'zodwa.admin@example.com', 'be5c9381fdaaa5b4f8d27f75be9756c3', 'Admin'),
(31, 'tshepiadmin', 'tshepang.ramohapi@gmail.com', 'TT', 'Admin'),
(32, 'red', 'red@gmail.com', '514f1b439f404f86f77090fa9edc96ce', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `tblaorder`
--

DROP TABLE IF EXISTS `tblaorder`;
CREATE TABLE IF NOT EXISTS `tblaorder` (
  `orderID` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `orderDate` datetime NOT NULL,
  `status` varchar(20) NOT NULL,
  `totalAmount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`orderID`),
  KEY `userID` (`userID`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblaorder`
--

INSERT INTO `tblaorder` (`orderID`, `userID`, `orderDate`, `status`, `totalAmount`) VALUES
(1, 1, '2026-05-01 10:30:00', 'Pending', 89.99),
(2, 2, '2026-05-02 14:15:00', 'Shipped', 129.98),
(3, 3, '2026-05-03 09:45:00', 'Delivered', 59.99),
(4, 4, '2026-05-04 16:20:00', 'Cancelled', 39.99),
(5, 5, '2026-05-05 11:00:00', 'Pending', 149.97),
(6, 1, '2026-04-01 10:15:00', 'Pending', 799.99),
(7, 2, '2026-04-02 14:30:00', 'Shipped', 499.99),
(8, 3, '2026-04-03 09:45:00', 'Delivered', 299.99),
(9, 4, '2026-04-04 16:20:00', 'Cancelled', 399.99),
(10, 5, '2026-04-05 11:10:00', 'Pending', 999.99),
(11, 6, '2026-04-06 13:55:00', 'Shipped', 249.99),
(12, 7, '2026-04-07 15:40:00', 'Delivered', 699.99),
(13, 8, '2026-04-08 12:25:00', 'Pending', 279.99),
(14, 9, '2026-04-09 17:05:00', 'Delivered', 229.99),
(15, 10, '2026-04-10 10:50:00', 'Cancelled', 1199.99),
(16, 11, '2026-04-11 14:15:00', 'Pending', 349.99),
(17, 12, '2026-04-12 09:30:00', 'Shipped', 299.99),
(18, 13, '2026-04-13 16:45:00', 'Delivered', 449.99),
(19, 14, '2026-04-14 11:20:00', 'Pending', 179.99),
(20, 15, '2026-04-15 13:05:00', 'Shipped', 599.99),
(21, 16, '2026-04-16 15:50:00', 'Delivered', 399.99),
(22, 17, '2026-04-17 12:35:00', 'Pending', 149.99),
(23, 18, '2026-04-18 17:10:00', 'Cancelled', 129.99),
(24, 19, '2026-04-19 10:55:00', 'Shipped', 699.99),
(25, 20, '2026-04-20 14:40:00', 'Delivered', 299.99),
(26, 1, '2026-04-21 09:25:00', 'Pending', 499.99),
(27, 2, '2026-04-22 11:15:00', 'Shipped', 349.99),
(28, 3, '2026-04-23 15:00:00', 'Delivered', 899.99),
(29, 4, '2026-04-24 16:45:00', 'Pending', 249.99),
(30, 5, '2026-04-25 13:30:00', 'Cancelled', 599.99);

-- --------------------------------------------------------

--
-- Table structure for table `tblclothes`
--

DROP TABLE IF EXISTS `tblclothes`;
CREATE TABLE IF NOT EXISTS `tblclothes` (
  `clothesID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `size` varchar(10) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`clothesID`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblclothes`
--

INSERT INTO `tblclothes` (`clothesID`, `name`, `category`, `size`, `price`, `stock`, `image`) VALUES
(1, 'Classic Jacket', 'Jackets', 'M', 59.99, 10, 'jacket.jpg'),
(2, 'Red Scotch Shirt', 'Shirts', 'L', 29.99, 25, 'shirt.jpg'),
(3, 'Leather Boots', 'Shoes', '42', 89.99, 8, 'boots.jpg'),
(4, 'Floral Sun Dress', 'Dresses', 'S', 49.99, 15, 'dress.jpg'),
(5, 'Plain Navy Hoodie', 'Sweaters', 'XL', 39.99, 20, 'hoodie.jpg'),
(6, 'Green Polo Shirt', 'Shirts', 'M', 25.99, 30, 'polo shirt.jpg'),
(7, 'Brown Leather Jacket', 'Jackets', 'L', 120.00, 12, 'brown leather jacket.jpg'),
(8, 'Shein Sneakers', 'Shoes', '7Uk', 350.00, 1, 'shein sneakers.jpg'),
(9, 'AirForce 1', 'Sneakers', '8UK', 850.00, 1, 'A1.jpg'),
(10, 'Fitted Cap', 'Jackets', 'M', 799.99, 5, 'fitted.jpg'),
(11, 'Ball gown', 'Dresses', 'S', 499.99, 10, 'MD.jpg'),
(12, 'Jordan 1', 'Shoes', '8', 299.99, 15, 'jordan.jpg'),
(13, 'Guess Jeans', 'Pants', '32', 399.99, 20, 'guess.jpg'),
(14, 'White T-Shirt', 'Shirts', 'L', 199.99, 25, 'plain.jpg'),
(15, 'Black Hoodie', 'Sweaters', 'XL', 349.99, 12, 'black.jpg'),
(16, 'Formal Suit', 'Suits', 'M', 999.99, 8, 'suit.jpg'),
(17, 'Nike Shox', 'Sneakers', 'M', 900.99, 18, 'shox.jpg'),
(18, 'Leather Boots', 'Shoes', '9', 699.99, 7, 'boots1.jpg'),
(19, 'Red Skirt', 'Dresses', 'S', 279.99, 14, 'skirt1.jpg'),
(20, 'Blue Polo Shirt', 'Shirts', 'M', 229.99, 22, 'polo1.jpg'),
(21, 'Winter Coat', 'Jackets', 'L', 1199.99, 6, 'coat1.jpg'),
(22, 'Casual Sneakers', 'Shoes', '10', 349.99, 16, 'sneakers2.jpg'),
(23, 'Green Cardigan', 'Sweaters', 'M', 299.99, 9, 'cardigan1.jpg'),
(24, 'Black Dress Pants', 'Pants', '34', 449.99, 11, 'pants1.jpg'),
(25, 'Graphic Tee', 'Shirts', 'S', 179.99, 30, 'tshirt2.jpg'),
(26, 'Sports Tracksuit', 'Sportswear', 'L', 599.99, 13, 'tracksuit1.jpg'),
(27, 'High Heels', 'Shoes', '7', 399.99, 10, 'heels1.jpg'),
(28, 'Wool Scarf', 'Accessories', '', 149.99, 40, 'scarf1.jpg'),
(29, 'Baseball Cap', 'Accessories', '', 129.99, 35, 'cap1.jpg'),
(30, 'Rain Jacket', 'Jackets', 'M', 699.99, 8, 'rainjacket1.jpg'),
(31, 'Striped Summer Shirt', 'Shirts', 'M', 249.99, 18, 'shirt2.jpg'),
(32, 'Woolen Sweater', 'Sweaters', 'L', 399.99, 12, 'sweater1.jpg'),
(33, 'Denim Jacket', 'Jackets', 'S', 599.99, 9, 'jacket2.jpg'),
(34, 'Casual Sandals', 'Shoes', '9', 199.99, 20, 'sandals1.jpg'),
(35, 'Evening Gown', 'Dresses', 'M', 1299.99, 5, 'MD.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblorder`
--

DROP TABLE IF EXISTS `tblorder`;
CREATE TABLE IF NOT EXISTS `tblorder` (
  `orderID` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `orderDate` datetime NOT NULL,
  `status` varchar(20) NOT NULL,
  `totalAmount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`orderID`),
  KEY `userID` (`userID`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblorder`
--

INSERT INTO `tblorder` (`orderID`, `userID`, `orderDate`, `status`, `totalAmount`) VALUES
(1, 1, '2026-05-01 10:30:00', 'Delivered', 89.99),
(2, 2, '2026-05-02 14:15:00', 'Shipped', 129.98),
(3, 3, '2026-05-03 09:45:00', 'Delivered', 59.99),
(4, 4, '2026-05-04 16:20:00', 'Cancelled', 39.99),
(5, 5, '2026-05-05 11:00:00', 'Pending', 149.97),
(6, 10, '2026-05-01 22:47:51', 'Pending', 219.96),
(7, 10, '2026-05-01 22:57:33', 'Pending', 39.99),
(8, 10, '2026-05-01 23:10:34', 'Pending', 850.00),
(9, 10, '2026-05-01 23:37:28', 'Pending', 879.99),
(10, 1, '2026-04-01 10:15:00', 'Pending', 799.99),
(11, 2, '2026-04-02 14:30:00', 'Shipped', 499.99),
(12, 3, '2026-04-03 09:45:00', 'Delivered', 299.99),
(13, 4, '2026-04-04 16:20:00', 'Cancelled', 399.99),
(14, 5, '2026-04-05 11:10:00', 'Pending', 999.99),
(15, 6, '2026-04-06 13:55:00', 'Shipped', 249.99),
(16, 7, '2026-04-07 15:40:00', 'Delivered', 699.99),
(17, 8, '2026-04-08 12:25:00', 'Pending', 279.99),
(18, 9, '2026-04-09 17:05:00', 'Delivered', 229.99),
(19, 10, '2026-04-10 10:50:00', 'Cancelled', 1199.99),
(20, 11, '2026-04-11 14:15:00', 'Shipped', 349.99),
(21, 12, '2026-04-12 09:30:00', 'Shipped', 299.99),
(22, 13, '2026-04-13 16:45:00', 'Delivered', 449.99),
(23, 14, '2026-04-14 11:20:00', 'Pending', 179.99),
(24, 15, '2026-04-15 13:05:00', 'Shipped', 599.99),
(25, 16, '2026-04-16 15:50:00', 'Delivered', 399.99),
(26, 17, '2026-04-17 12:35:00', 'Cancelled', 149.99),
(27, 18, '2026-04-18 17:10:00', 'Cancelled', 129.99),
(28, 19, '2026-04-19 10:55:00', 'Shipped', 699.99),
(29, 20, '2026-04-20 14:40:00', 'Delivered', 299.99),
(30, 1, '2026-04-21 09:25:00', 'Pending', 499.99),
(31, 31, '2026-05-03 12:11:03', 'Pending', 599.99),
(32, 32, '2026-05-03 13:37:30', 'Cancelled', 59.99);

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE IF NOT EXISTS `tbluser` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `fullName` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `verified` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`userID`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`userID`, `fullName`, `email`, `username`, `password`, `verified`) VALUES
(1, 'John Doe', 'johndoe@example.com', 'johndoe', '2c103f2c4ed1e59c0b4e2e01821770fa', 1),
(2, 'Jane Smith', 'jane.smith@example.com', 'janesmith', 'ceb1f46914d06e44b4f8b4f8531223b3', 0),
(3, 'Michael Brown', 'michaelb@example.com', 'mikebrown', 'dc387da9bb320e7ea3eed60847736fe4', 0),
(4, 'Emily Johnson', 'emilyj@example.com', 'emilyj', '534d367dfbb8de8eceb36e349eba5f0a', 0),
(7, 'tshepang', 'tshepang.ramohapi06@gmail.com', 'tshepang', '7ca8ccd9e2499531fc986d7153444a1d', 1),
(6, 'Sarah Lee', 'sarah@example.com', 'sarahlee', '6c11001a0122297e3559d5b790b64e65', 1),
(8, 'siya', 'siya@gmail.com', 'siya1', '3691308f2a4c2f6983f2880d32e29c84', 0),
(9, 'Masego', 'masego@gmail.com', 'masego1', 'c8211034acf9bc096e09a5f2846b209e', 0),
(10, 'Siyanda Masego Mazibuko', 'siyaa@gmail.com', 'Yanda', 'e0323a9039add2978bf5b49550572c7c', 1),
(11, 'Sipho Dlamini', 'sipho.dlamini@example.com', 'sipho', 'a722c63db8ec8625af6cf71cb8c2d939', 1),
(12, 'Thandiwe Nkosi', 'thandiwe.nkosi@example.com', 'thandiwe', 'c1572d05424d0ecb2a65ec6a82aeacbf', 0),
(13, 'Kabelo Mokoena', 'kabelo.mokoena@example.com', 'kabelo', '3afc79b597f88a72528e864cf81856d2', 1),
(14, 'Nomsa Khumalo', 'nomsa.khumalo@example.com', 'nomsa', 'fc2921d9057ac44e549efaf0048b2512', 0),
(15, 'Johan van der Merwe', 'johan.vdm@example.com', 'johanvdm', 'd35f6fa9a79434bcd17f8049714ebfcb', 1),
(16, 'Annelie Botha', 'annelie.botha@example.com', 'annelie', 'e9568c9ea43ab05188410a7cf85f9f5e', 0),
(17, 'Sibusiso Zulu', 'sibusiso.zulu@example.com', 'sibusiso', '8c96c3884a827355aed2c0f744594a52', 1),
(18, 'Ayanda Mthembu', 'ayanda.mthembu@example.com', 'ayanda', 'ccd3cd18225730c5edfc69f964b9d7b3', 0),
(19, 'Rajesh Naidoo', 'rajesh.naidoo@example.com', 'rajesh', 'c28cce9cbd2daf76f10eb54478bb0454', 1),
(20, 'Prisha Pillay', 'prisha.pillay@example.com', 'prisha', 'a3224611fd03510682690769d0195d66', 0),
(21, 'Lethabo Molefe', 'lethabo.molefe@example.com', 'lethabo', '0102812fbd5f73aa18aa0bae2cd8f79f', 1),
(22, 'Boitumelo Seabi', 'boitumelo.seabi@example.com', 'boitumelo', '0bd0fe6372c64e09c4ae81e056a9dbda', 0),
(23, 'Gugu Cele', 'gugu.cele@example.com', 'gugu', 'c868bff94e54b8eddbdbce22159c0299', 1),
(24, 'Xolani Mbatha', 'xolani.mbatha@example.com', 'xolani', 'd1f38b569c772ebb8fa464e1a90c5a00', 0),
(25, 'Mpho Radebe', 'mpho.radebe@example.com', 'mpho', 'b279786ec5a7ed00dbe4d3fe1516c121', 1),
(26, 'Zanele Mhlongo', 'zanele.mhlongo@example.com', 'zanele', '66c99bf933f5e6bf3bf2052d66577ca8', 0),
(27, 'Pieter de Klerk', 'pieter.deklerk@example.com', 'pieter', '6c2a5c9ead1d7d6ba86c8764d5cad395', 1),
(28, 'Chantelle du Plessis', 'chantelle.dp@example.com', 'chantelle', '64152ab7368fc7ca6b3ef6b71e330b86', 0),
(29, 'Thabo Masilela', 'thabo.masilela@example.com', 'thabo', '1f61b744f2c9e8f49ae4c4965f39963f', 1),
(30, 'Nandi Sibanda', 'nandi.sibanda@example.com', 'nandi', '90bfa11df19a9b9d429ccfa6997104df', 0),
(31, 'Daniel Ramo', 'dani@gmail.com', 'dani', '1aabac6d068eef6a7bad3fdf50a05cc8', 1),
(32, 'Abby', 'abby@gmail.com', 'abby1', '4124bc0a9335c27f086f24ba207a4912', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
