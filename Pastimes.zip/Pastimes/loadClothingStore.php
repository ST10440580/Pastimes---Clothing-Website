<?php
// loadClothingStore.php
include("config/DBConn.php");

// Drop existing tables if they exist
$conn->query("DROP TABLE IF EXISTS tblaorder");
$conn->query("DROP TABLE IF EXISTS tblorder");
$conn->query("DROP TABLE IF EXISTS tblclothes");
$conn->query("DROP TABLE IF EXISTS tbladmin");
$conn->query("DROP TABLE IF EXISTS tbluser");

// Create tbluser
$sqlUser = "CREATE TABLE tbluser (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    fullName VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    verified ENUM('Pending','Approved') DEFAULT 'Pending'
)";
$conn->query($sqlUser);

// Create tbladmin
$sqlAdmin = "CREATE TABLE tbladmin (
    adminID INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
)";
$conn->query($sqlAdmin);

// Create tblclothes
$sqlClothes = "CREATE TABLE tblclothes (
    clothesID INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    size VARCHAR(10),
    price DECIMAL(10,2) NOT NULL,
    stock INT DEFAULT 0,
    image VARCHAR(255) DEFAULT NULL
)";
$conn->query($sqlClothes);

// Create tblOrder
$sqlOrder = "CREATE TABLE tblorder (
    orderID INT AUTO_INCREMENT PRIMARY KEY,
    userID INT NOT NULL,
    orderDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Pending','Shipped','Delivered','Cancelled') DEFAULT 'Pending',
    totalAmount DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (userID) REFERENCES tblUser(userID)
)";
$conn->query($sqlOrder);

// Create tblAorder
$sqlAorder = "CREATE TABLE tblaorder (
    orderID INT AUTO_INCREMENT PRIMARY KEY,
    userID INT NOT NULL,
    orderDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Pending','Shipped','Delivered','Cancelled') DEFAULT 'Pending',
    totalAmount DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (userID) REFERENCES tblUser(userID)
)";
$conn->query($sqlAorder);

// Insert sample users
$conn->query("INSERT INTO tbluser (fullName, email, username, password, verified) VALUES
    ('Alice Johnson', 'alice@example.com', 'alice', MD5('password123'), 'Approved'),
    ('Bob Smith', 'bob@example.com', 'bob', MD5('securepass'), 'Pending')");

// Insert sample admin
$conn->query("INSERT INTO tbladmin (username, email, password) VALUES
    ('admin', 'admin@example.com', MD5('admin123'))");

// Insert sample clothes with images
$conn->query("INSERT INTO tblclothes (name, category, size, price, stock, image) VALUES
    ('Brown Leather Jacket', 'Jackets', 'M', 799.99, 5, 'brown leather jacket.jpg'),
    ('Elegant Dress', 'Dresses', 'S', 499.99, 10, 'dress.jpg'),
    ('Sneakers', 'Shoes', '8', 299.99, 15, 'shein sneakers.jpg')");

// Insert sample order
$conn->query("INSERT INTO tblorder (userID, status, totalAmount) VALUES
    (1, 'Pending', 799.99)");

$conn->query("INSERT INTO tblaorder (userID, status, totalAmount) VALUES
    (1, 'Pending', 799.99)");

echo "<h3>ClothingStore database loaded successfully!</h3>";
echo "<p>Tables created and sample data inserted (users, admin, clothes with images, orders).</p>";
?>
