<!DOCTYPE html>
<html>
<head>
    <title>Privacy Policy</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>Pastimes</header>
   

    <section class="about">
        <h2>Privacy Policy</h2>
        <p>We respect your privacy and are committed to protecting your personal information. 
        This policy explains how we collect, use, and safeguard your data when you use our website.</p>
        <p>We do not sell or rent your information. Data may be shared only with trusted service providers 
        for order fulfillment and customer support.</p>
        <p>You have the right to access, update, or delete your personal information at any time.</p>
    </section>

   <!-- Footer -->
    <footer>
        <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
        <p>
             <a href="index.php">Home</a> | 
            <a href="contact.php">Contact Us</a> | 
            <a href="about.php">About</a> | 
            <a href="privacy.php">Privacy Policy</a>
        </p>
    </footer>

</body>
</html>