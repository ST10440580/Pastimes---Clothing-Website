<?php
include("config/DBConn.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName = $_POST['fullName'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = md5($_POST['password']); // simple hashing, consider password_hash() for stronger security

    $sql = "INSERT INTO tbluser (fullName, email, username, password, verified, role)
            VALUES ('$fullName', '$email', '$username', '$password', 0, 'Seller')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Seller registered successfully!'); window.location.href='sellerLogin.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Seller Registration</title>
    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<nav class="store-nav">
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes Seller Portal</span>
  </div>
  <div class="nav-links">
    <a href="index.php"><i class="fas fa-home"></i><span>Home</span></a>
    <a href="products.php"><i class="fas fa-tshirt"></i><span>Products</span></a>
    <a href="sellerLogin.php"><i class="fas fa-sign-in-alt"></i><span>Login</span></a>
  </div>
</nav>

<body>
   
    <form method="post">
         <h2>Seller Registration</h2>
        <label>Full Name:</label><input type="text" name="fullName" required><br>
        <label>Email:</label><input type="email" name="email" required><br>
        <label>Username:</label><input type="text" name="username" required><br>
        <label>Password:</label><input type="password" name="password" required><br>
        <input type="submit" value="Register">
    </form>
</body>


<footer>
  <div class="footer-links">
    <h4>Quick Links</h4>
    <p>
      <a href="contact.php">Contact Us</a> | 
      <a href="about.php">About</a> | 
      <a href="privacy.php">Privacy Policy</a> | 
      <a href="faq.php">FAQ</a> | 
      <a href="returns.php">Returns & Exchanges</a>
    </p>
  </div>

  <div class="footer-info">
    <h4>Store Info</h4>
    <p>📍 Johannesburg, South Africa</p>
    <p>📧 support@pastimes.com</p>
    <p>☎ +27 11 123 4567</p>
    <p>🕒 Mon–Fri: 9am – 6pm | Sat: 10am – 4pm</p>
  </div>

  <div class="footer-social">
    <h4>Follow Us</h4>
    <a href="https://www.facebook.com">Facebook</a>
    <a href="https://www.instagram.com">Instagram</a>
    <a href="https://www.twitter.com">Twitter</a>
  </div>

  <div class="footer-bottom">
    <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
  </div>
</footer>
</html>
