<?php
session_start();

//Get the clothing id 
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);


    // Check if cart exists
    if (isset($_SESSION['cart'])) {

    //Find the piece of clothing and remove
        $index = array_search($id, $_SESSION['cart']);

        if ($index !== false) {
            unset($_SESSION['cart'][$index]);

            // Reindex array to avoid gaps
            $_SESSION['cart'] = array_values($_SESSION['cart']);
        }
    }
}

// Redirect back to cart
header("Location: viewCart.php");
exit;
?>
