<?php
include("config/DBConn.php");
session_start();

// Fetch all products
$sql = "SELECT * FROM tblclothes ORDER BY category, name";
$result = $conn->query($sql);

// Fetch distinct categories
$catSql = "SELECT DISTINCT category FROM tblclothes ORDER BY category";
$catResult = $conn->query($catSql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Products - Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<!-- Navigation -->
<nav>
  <div class="nav-logo">
    <img src="images/pastimeslogo.jpg" alt="Pastimes Logo">
    <span class="brand-name">Pastimes</span>
  </div>
  <div class="nav-links">
    <a href="viewCart.php"><i class="fas fa-shopping-cart"></i><span>My Cart</span></a>
    <a href="index.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
  </div>
</nav>

<h2 class="page-title">🛍️ Our Products</h2>

<!-- Search + Filter Section -->
<div class="filter-bar">
    <input type="text" id="searchInput" placeholder="Search products...">
    <div class="category-buttons">
        <button onclick="filterCategory('All')">All</button>
        <?php
        if ($catResult->num_rows > 0) {
            while ($catRow = $catResult->fetch_assoc()) {
                $cat = htmlspecialchars($catRow['category']);
                echo "<button onclick=\"filterCategory('".$cat."')\">".$cat."</button>";
            }
        }
        ?>
    </div>
</div>

<?php
if ($result->num_rows > 0) {
    $currentCategory = "";
    echo "<div class='products-container'>";
    while ($row = $result->fetch_assoc()) {
        // Print category heading when it changes
        if ($currentCategory !== $row['category']) {
            if ($currentCategory !== "") {
                echo "</div>"; // close previous grid
            }
            $currentCategory = $row['category'];
            echo "<h3 class='category-title'>".$currentCategory."</h3>";
            echo "<div class='product-grid'>";
        }

        // Product card
        echo "<div class='product-card' data-category='".$row['category']."'>
                <img src='images/".$row['image']."' alt='".$row['name']."' class='product-img'>
                <h3>".$row['name']."</h3>
                <p>Size: ".$row['size']."</p>
                <p>Price: R".$row['price']."</p>
                <p>Stock: ".$row['stock']."</p>
                <a href='addToCart.php?id=".$row['clothesID']."' class='btn-cart'>Add to Cart</a>
              </div>";
    }
    echo "</div>"; // close last grid
    echo "</div>"; // close container
} else {
    echo "<p class='inbox-empty'>No products found.</p>";
}
?>

<footer>
  <div class="footer-links">
    <h4>Quick Links</h4>
    <p>
      <a href="contact.php">Contact Us</a> | 
      <a href="about.php">About</a> | 
      <a href="privacy.php">Privacy Policy</a> | 
      <a href="faq.php">FAQ</a> | 
      <a href="returns.php">Returns & Exchanges</a>
    </p>
  </div>

  <div class="footer-info">
    <h4>Store Info</h4>
    <p>📍 Johannesburg, South Africa</p>
    <p>📧 support@pastimes.com</p>
    <p>☎ +27 11 123 4567</p>
    <p>🕒 Mon–Fri: 9am – 6pm | Sat: 10am – 4pm</p>
  </div>

  <div class="footer-social">
    <h4>Follow Us</h4>
    <a href="https://www.facebook.com">Facebook</a>
    <a href="https://www.instagram.com">Instagram</a>
    <a href="https://www.twitter.com">Twitter</a>
  </div>

  <div class="footer-bottom">
    <p>&copy; 2026 Pastimes Clothing Store. All rights reserved.</p>
  </div>
</footer>

<script>
function filterCategory(category) {
    const cards = document.querySelectorAll('.product-card');
    cards.forEach(card => {
        const categoryAttr = card.getAttribute('data-category');
        if (category === 'All' || categoryAttr === category) {
            card.style.display = 'block';
            card.style.opacity = 1;
        } else {
            card.style.opacity = 0;
            setTimeout(() => card.style.display = 'none', 300);
        }
    });
}


document.getElementById('searchInput').addEventListener('keyup', function() {
    const searchValue = this.value.toLowerCase();
    const cards = document.querySelectorAll('.product-card');
    cards.forEach(card => {
        const name = card.querySelector('h3').innerText.toLowerCase();
        if (name.includes(searchValue)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
});
</script>

</body>
</html>
