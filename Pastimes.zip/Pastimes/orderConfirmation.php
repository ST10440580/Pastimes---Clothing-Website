

 <link rel="stylesheet" href="css/style.css">
<div class="confirmation">
  <h2>✅ Thank you for your order!</h2>
  <p>Your delivery details have been saved. We’ll notify you once your package is on the way.</p>
  <a href="products.php" class="btn-cart">Shop Again</a>
</div>
